<?php
echo "VOCÊ PRECISA TER O NIVEL 2 PARA ACESSAR ESSA PAGINA";
?>
<br>
<p><a href="index.php">Voltar</a></p>