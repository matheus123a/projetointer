<?php
include 'conecta.php';

$consulta = "SELECT *FROM produtos";

foreach ($conexao->query($consulta) as $linha) {
    echo "<br>";
    echo "ID: " . $linha['id'] . "<br>";
    echo "Nome: " . $linha['nome'] . "<br>";
    echo "Valor: " . $linha['preco'] . "<br>";

    echo "<hr>";
    
}
echo "<br>";
?>
<p><a href="index.php"> VOLTAR INICIO</a></p>