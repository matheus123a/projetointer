
<!DOCTYPE html>
<html>
    <head>
        <title>Fala fiot</title>
    </head>
    <body>
        <h1>Fala fiot</h1>

        <form action="Processa.php" method="post">
            Digite seu email: <input type="text" name="email"><br>
            Digite sua senha: <input type="text" name="senha"><br>
            <br>
            <hr>
            <input type="submit" value="Login">
        </form>
        
    </body>
</html>